import time
import lirc
import config
import gps_module
import camera_module
import audio_module
import network_module
import voice_module
import requests

def describe_landscape():
    img_bytes = camera_module.capture_image_bytes()
    with gps_module.location_lock:
        lat, lon = gps_module.latest_location['lat'], gps_module.latest_location['lon']
    if img_bytes and lat and lon:
        try:
            files = {'image': ('capture.jpg', img_bytes, 'image/jpeg')}
            data = {'device_id': config.DEVICE_ID}
            res = requests.post(f"{config.SERVER_URL}/api/v1/hw/auto_describe", files=files, data=data)
            if res.status_code == 200:
                audio_module.play_mp3_binary(res.content)
        except Exception as e:
            print(f"❌ 요청 실패: {e}")

def handle_key_pattern(count, duration):
    if duration >= 3.0:
        audio_module.play_local_mp3(config.LOCAL_MP3_PATH)
    elif count == 1:
        describe_landscape()
    elif count == 2:
        voice_module.respond_to_prompt()
    elif count == 5:
        eid = network_module.get_emergency_id()
        if eid:
            network_module.burst_send_images(eid)

def ir_listener():
    lirc.init("myprogram", blocking=False)
    press_time = None
    press_count = 0
    last_press = 0

    while True:
        codes = lirc.nextcode()
        if codes and codes[0] == "KEY_1":
            now = time.time()
            if press_time is None:
                press_time = now
                last_press = now
                press_count = 1
            elif now - last_press <= 0.8:
                press_count += 1
                last_press = now
            else:
                handle_key_pattern(press_count, last_press - press_time)
                press_time = now
                last_press = now
                press_count = 1

        if press_time and time.time() - last_press > 1.0:
            handle_key_pattern(press_count, last_press - press_time)
            press_time = None
            press_count = 0

        time.sleep(0.05)
