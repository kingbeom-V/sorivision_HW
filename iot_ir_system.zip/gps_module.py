import time
import threading

latest_location = {'lat': None, 'lon': None}
location_lock = threading.Lock()

def parse_gprmc(sentence):
    try:
        parts = sentence.split(',')
        if parts[2] != 'A':
            return None, None
        lat = convert_to_decimal(parts[3], parts[4])
        lon = convert_to_decimal(parts[5], parts[6])
        return lat, lon
    except:
        return None, None

def convert_to_decimal(raw, direction):
    if not raw:
        return None
    d, m = (float(raw[:2]), float(raw[2:])) if direction in ['N', 'S'] else (float(raw[:3]), float(raw[3:]))
    return -1 * (d + m / 60.0) if direction in ['S', 'W'] else round(d + m / 60.0, 6)

def gps_reader(ser):
    import gps_module
    while True:
        if ser.in_waiting:
            line = ser.readline().decode('ascii', errors='replace').strip()
            if line.startswith('$GPRMC'):
                lat, lon = parse_gprmc(line)
                if lat and lon:
                    with location_lock:
                        gps_module.latest_location['lat'] = lat
                        gps_module.latest_location['lon'] = lon
        time.sleep(1)
