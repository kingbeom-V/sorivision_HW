import threading
import time
import serial
import gps_module
import ir_handler
import config

if __name__ == "__main__":
    try:
        ser = serial.Serial('/dev/serial0', 9600, timeout=1)
    except Exception as e:
        print(f"❌ 시리얼 포트 오류: {e}")
        exit()

    print(f"✅ 기기 ID: {config.DEVICE_ID}")

    threading.Thread(target=gps_module.gps_reader, args=(ser,), daemon=True).start()
    threading.Thread(target=ir_handler.ir_listener, daemon=True).start()

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        ser.close()
        print("🛑 종료됨")
