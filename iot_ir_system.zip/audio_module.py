import os
import io
from pydub import AudioSegment
from pydub.playback import play

def set_audio_output_to_jack():
    os.system("amixer cset numid=3 1")

def play_mp3_binary(mp3_bytes):
    set_audio_output_to_jack()
    audio = AudioSegment.from_file(io.BytesIO(mp3_bytes), format="mp3")
    play(audio)

def play_local_mp3(filepath):
    try:
        set_audio_output_to_jack()
        audio = AudioSegment.from_file(filepath, format="mp3")
        play(audio)
    except Exception as e:
        print(f"❌ 로컬 MP3 재생 실패: {e}")
