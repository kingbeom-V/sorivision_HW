import speech_recognition as sr
import camera_module
import config
import audio_module
import requests

def recognize_speech():
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        print("🎙️ 말해주세요...")
        audio = recognizer.listen(source, timeout=5, phrase_time_limit=7)
    try:
        return recognizer.recognize_google(audio, language='ko-KR')
    except:
        return None

def respond_to_prompt():
    img_bytes = camera_module.capture_image_bytes()
    prompt_text = recognize_speech()
    if not img_bytes or not prompt_text:
        print("⚠️ 입력 부족")
        return
    try:
        files = {'image': ('capture.jpg', img_bytes, 'image/jpeg')}
        data = {'device_id': config.DEVICE_ID, 'prompt': prompt_text}
        res = requests.post(f"{config.SERVER_URL}/api/v1/hw/user_qa", files=files, data=data)
        if res.status_code == 200:
            audio_module.play_mp3_binary(res.content)
    except Exception as e:
        print(f"❌ 요청 실패: {e}")
