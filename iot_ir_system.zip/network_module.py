import requests
import time
import config
import camera_module

def send_http(lat, lon):
    try:
        res = requests.post(f"{config.SERVER_URL}/api/v1/hw/gps", json={
            'device_id': config.DEVICE_ID,
            'lat': lat,
            'lon': lon
        })
        print(f"📡 전송 완료: {lat}, {lon}, 상태: {res.status_code}")
    except Exception as e:
        print(f"❌ 전송 실패: {e}")

def get_emergency_id():
    try:
        res = requests.post(f"{config.SERVER_URL}/api/v1/hw/get_emergency_id", json={
            'device_id': config.DEVICE_ID,
        })
        if res.status_code == 200:
            emergency_id = res.json().get("emergency_id")
            if emergency_id:
                print(f"✅ Emergency ID: {emergency_id}")
                return emergency_id
    except Exception as e:
        print(f"❌ 전송 실패: {e}")
    return None

def burst_send_images(emergency_id):
    for i in range(10):
        img_bytes = camera_module.capture_image_bytes()
        if img_bytes:
            try:
                files = {'image': (f'frame_{i}.jpg', img_bytes, 'image/jpeg')}
                data = {'device_id': config.DEVICE_ID, 'emergency_id': emergency_id}
                res = requests.post(f"{config.SERVER_URL}/api/v1/hw/emergency_img", files=files, data=data)
                print(f"📸 이미지 전송 {i+1}/10, 상태: {res.status_code}")
            except Exception as e:
                print(f"❌ 이미지 전송 실패: {e}")
        else:
            print(f"⚠️ 이미지 캡처 실패 ({i+1}/10)")
        time.sleep(1)
