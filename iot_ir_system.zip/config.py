DEVICE_ID = "raspi-001"
LOCAL_MP3_PATH = "/home/pi/sounds/help.mp3"
SERVER_URL = "http://your.server.com"
